(function () {
  const bridge = document.getElementById("job-tracker-token-bridge");
  if (!bridge) return;

  const token = bridge.getAttribute("data-token");
  if (!token) return;

  chrome.storage.sync.set({ extensionToken: token }, () => {
    bridge.setAttribute("data-connected", "true");
  });
})();
