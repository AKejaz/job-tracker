const tokenInput = document.getElementById("token");
const statusEl = document.getElementById("status");

chrome.storage.sync.get("extensionToken", ({ extensionToken }) => {
  if (extensionToken) tokenInput.value = extensionToken;
});

document.getElementById("save").addEventListener("click", async () => {
  const value = tokenInput.value.trim();
  if (!value) {
    statusEl.textContent = "Enter a token first.";
    statusEl.style.color = "#dc2626";
    return;
  }
  await chrome.storage.sync.set({ extensionToken: value });
  statusEl.textContent = "Saved ✓";
  statusEl.style.color = "#059669";
});
