const API_URL = "https://job-tracker-lilac-pi.vercel.app/api/extension/log";

const statusEl = document.getElementById("status");
const saveBtn = document.getElementById("save");
const setupLink = document.getElementById("setup-link");

setupLink.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

function extractJobData() {
  function fromJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
      try {
        const parsed = JSON.parse(script.textContent || "{}");
        const candidates = Array.isArray(parsed) ? parsed : [parsed];
        for (const item of candidates) {
          if (item["@type"] === "JobPosting" || (Array.isArray(item["@type"]) && item["@type"].includes("JobPosting"))) {
            const org = item.hiringOrganization;
            const companyName = typeof org === "string" ? org : org?.name;
            let pay = null;
            const salary = item.baseSalary?.value;
            if (salary) {
              if (salary.value) pay = String(salary.value);
              else if (salary.minValue && salary.maxValue) pay = `${salary.minValue}-${salary.maxValue}`;
            }
            return { job_title: item.title || null, company_name: companyName || null, pay };
          }
        }
      } catch {}
    }
    return null;
  }
  function fromMetaTags() {
    function meta(prop) {
      const el = document.querySelector(`meta[property="${prop}"], meta[name="${prop}"]`);
      return el?.getAttribute("content") || null;
    }
    return { job_title: meta("og:title") || document.title || null, company_name: meta("og:site_name") || null, pay: null };
  }
  function guessMedium() {
    const host = window.location.hostname;
    if (host.includes("linkedin.com")) return "linkedin";
    if (host.includes("indeed.com")) return "indeed";
    return "company_site";
  }
  const data = fromJsonLd() || fromMetaTags();
  return { ...data, job_url: window.location.href, medium: guessMedium() };
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: extractJobData,
  });

  document.getElementById("job_title").value = result?.job_title || "";
  document.getElementById("company_name").value = result?.company_name || "";
  document.getElementById("pay").value = result?.pay || "";
  document.getElementById("medium").value = result?.medium || "other";

  saveBtn.dataset.jobUrl = result?.job_url || tab.url || "";
}

saveBtn.addEventListener("click", async () => {
  const { extensionToken } = await chrome.storage.sync.get("extensionToken");
  if (!extensionToken) {
    statusEl.textContent = "Set up your token first (link below).";
    statusEl.style.color = "#dc2626";
    return;
  }

  const job_title = document.getElementById("job_title").value.trim();
  const company_name = document.getElementById("company_name").value.trim();
  const pay = document.getElementById("pay").value.trim();
  const medium = document.getElementById("medium").value;

  if (!job_title || !company_name) {
    statusEl.textContent = "Position and company are required.";
    statusEl.style.color = "#dc2626";
    return;
  }

  saveBtn.disabled = true;
  statusEl.textContent = "Saving…";
  statusEl.style.color = "#6b7280";

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${extensionToken}` },
      body: JSON.stringify({
        job_title, company_name, pay: pay || null, medium,
        job_url: saveBtn.dataset.jobUrl,
        applied_at: new Date().toISOString(),
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Failed to save");
    statusEl.textContent = "Saved to your dashboard ✓";
    statusEl.style.color = "#059669";
  } catch (err) {
    statusEl.textContent = err.message || "Something went wrong.";
    statusEl.style.color = "#dc2626";
  }
  saveBtn.disabled = false;
});

init();
